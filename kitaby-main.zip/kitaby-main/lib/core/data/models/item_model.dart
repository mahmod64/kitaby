class ItemModel {
  final String bookISBN;
  final int quantity;

  const ItemModel({required this.bookISBN, required this.quantity});
}
