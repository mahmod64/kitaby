part of 'select_image_bloc.dart';

@immutable
class SelectImageEvent {}
