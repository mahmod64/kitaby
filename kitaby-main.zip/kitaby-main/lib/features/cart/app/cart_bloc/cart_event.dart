part of 'cart_bloc.dart';

@immutable
class CartEvent {}
