part of 'favorites_bloc.dart';

@immutable
class FavoritesEvent {}
