part of 'orders_bloc.dart';

@immutable
class OrdersEvent {}
